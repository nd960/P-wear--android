const products = [
 {id:1,name:"Classic Black Hoodie",category:"Men",price:1799,emoji:"🧥",bg:"#e7e4dc",tag:"BESTSELLER"},
 {id:2,name:"Everyday White Tee",category:"Men",price:999,emoji:"👕",bg:"#e9e9e7",tag:"ESSENTIAL"},
 {id:3,name:"Street Sneakers",category:"Shoes",price:2999,emoji:"👟",bg:"#e7e2d9",tag:"NEW"},
 {id:4,name:"Everyday Cap",category:"Accessories",price:799,emoji:"🧢",bg:"#e7e8e4",tag:""},
 {id:5,name:"Statement Red Top",category:"Women",price:1299,emoji:"👚",bg:"#f0e2df",tag:"POPULAR"},
 {id:6,name:"Weekend Denim",category:"Women",price:2199,emoji:"👖",bg:"#dce4eb",tag:""},
 {id:7,name:"Kids Cozy Hoodie",category:"Kids",price:1499,emoji:"🧸",bg:"#e9e2ef",tag:""},
 {id:8,name:"Everyday Backpack",category:"Accessories",price:1899,emoji:"🎒",bg:"#e7e2d9",tag:""}
];
let cart = JSON.parse(localStorage.getItem("pwear-cart") || "{}");
let activeCategory = "All";
const money = n => "KSh " + n.toLocaleString("en-KE");
function save(){localStorage.setItem("pwear-cart",JSON.stringify(cart));renderCart();}
function renderProducts(){
 const filtered=products.filter(p=>activeCategory==="All"||p.category===activeCategory);
 document.getElementById("products").innerHTML=filtered.map(p=>`
 <article class="product"><div class="product-art" style="background:${p.bg}">${p.tag?`<span class="tag">${p.tag}</span>`:""}<span>${p.emoji}</span></div>
 <div class="product-info"><div class="type">${p.category}</div><h3>${p.name}</h3><div class="price-row"><span class="price">${money(p.price)}</span><button class="add" aria-label="Add ${p.name}" data-add="${p.id}">+</button></div></div></article>`).join("");
}
function renderCart(){
 const entries=Object.entries(cart).filter(([,qty])=>qty>0);
 const count=entries.reduce((s,[,q])=>s+q,0);
 const total=entries.reduce((s,[id,q])=>s+products.find(p=>p.id===Number(id)).price*q,0);
 document.getElementById("cartCount").textContent=count;
 document.getElementById("cartTotal").textContent=money(total);
 document.getElementById("cartItems").innerHTML=entries.length?entries.map(([id,q])=>{const p=products.find(x=>x.id===Number(id));return `<div class="cart-item"><div class="mini-art">${p.emoji}</div><div class="cart-item-main"><b>${p.name}</b><small>${money(p.price)} each</small></div><div class="quantity"><button data-minus="${id}" aria-label="Remove one">−</button><b>${q}</b><button data-plus="${id}" aria-label="Add one">+</button></div></div>`}).join(""):`<p class="empty">Your bag is waiting for something good.</p>`;
}
let toastTimer;
function toast(message){const el=document.getElementById("toast");el.textContent=message;el.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove("show"),2200);}
document.addEventListener("click",e=>{
 const add=e.target.closest("[data-add]"); if(add){const id=add.dataset.add;cart[id]=(cart[id]||0)+1;save();toast("Added to your bag");}
 const plus=e.target.closest("[data-plus]");if(plus){const id=plus.dataset.plus;cart[id]=(cart[id]||0)+1;save();}
 const minus=e.target.closest("[data-minus]");if(minus){const id=minus.dataset.minus;cart[id]--;if(cart[id]<=0)delete cart[id];save();}
 const cat=e.target.closest("[data-category]");if(cat){activeCategory=cat.dataset.category;document.querySelectorAll(".category").forEach(x=>x.classList.toggle("active",x===cat));renderProducts();}
});
document.getElementById("cartJump").addEventListener("click",()=>document.getElementById("checkout").scrollIntoView({behavior:"smooth"}));
document.getElementById("orderForm").addEventListener("submit",e=>{
 e.preventDefault();
 const entries=Object.entries(cart).filter(([,q])=>q>0);
 if(!entries.length){toast("Add at least one item before ordering");return;}
 const name=document.getElementById("customerName").value.trim();
 const phone=document.getElementById("customerPhone").value.trim();
 const location=document.getElementById("customerLocation").value.trim();
 const payment=document.getElementById("paymentMethod").value;
 const lines=entries.map(([id,q])=>{const p=products.find(x=>x.id===Number(id));return `• ${p.name} x${q} — ${money(p.price*q)}`});
 const total=entries.reduce((s,[id,q])=>s+products.find(p=>p.id===Number(id)).price*q,0);
 const message=`Hello P WEAR! I'd like to place an order:\n\n${lines.join("\n")}\n\nEstimated total: ${money(total)}\nName: ${name}\nPhone: ${phone}\nDelivery location: ${location}\nPayment preference: ${payment}\n\nPlease confirm availability, delivery fee and payment instructions.`;
 // WhatsApp recipient is the shop's first supplied contact number.
 const whatsappNumber="254112968846";
 window.open(`https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`,"_blank","noopener");
});
document.getElementById("year").textContent=new Date().getFullYear();
renderProducts();renderCart();
if("serviceWorker" in navigator && location.protocol.startsWith("http")) navigator.serviceWorker.register("./sw.js").catch(()=>{});
