P WEAR ANDROID APP PROJECT

This is an Android Studio project wrapper for the P WEAR shop starter website.
It is source code, not a compiled APK file. This environment does not have the Android SDK/Gradle build setup needed to compile and sign an APK directly.

HOW TO BUILD AN APK
1. Install Android Studio on a computer from the official Android Developers website.
2. Extract this ZIP.
3. In Android Studio, choose Open and select the extracted PWear folder.
4. Allow Gradle sync and install the Android SDK components it requests.
5. Use Build > Build Bundle(s) / APK(s) > Build APK(s).
6. When the build finishes, click Locate to find the APK.
7. For personal testing, transfer the APK to your Android phone and install it. Only install APKs you built or trust.

WHAT IS INCLUDED
- P WEAR shopping UI, catalogue, categories, cart and WhatsApp order form.
- Basic Android WebView app shell.
- Local app assets so the shopping UI loads from inside the app.

IMPORTANT
- WhatsApp ordering is implemented, but verify the shop WhatsApp number in app.js.
- Live M-Pesa and bank payment processing is NOT integrated.
- Sample products/prices are placeholders. Replace with actual inventory before launch.
- This is not published on Google Play.
- For Google Play release, signing, policy requirements, testing, privacy policy, and store listing are still needed.
